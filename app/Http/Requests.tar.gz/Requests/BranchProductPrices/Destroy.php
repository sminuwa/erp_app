<?php

namespace App\Http\Requests\BranchProductPrices;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\BranchProductPrice;

class Destroy extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return $this->user()->can('branch_product_prices.destroy', BranchProductPrice::class);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [

        ];
    }

    /**
    * Get the error messages for the defined validation rules.
    *
    * @return array
    */
    public function messages()
    {
        return [

        ];
    }

}
